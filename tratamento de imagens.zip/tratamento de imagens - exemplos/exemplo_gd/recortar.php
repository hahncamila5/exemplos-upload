<?php
// Carregar a imagem original
$imagem = imagecreatefromjpeg('caminho/para/imagem.jpg');

// Definir as coordenadas e dimensões do retângulo de corte
$x = 100;
$y = 100;
$largura = 200;
$altura = 150;

// Criar uma nova imagem recortada
$novaImagem = imagecrop($imagem, ['x' => $x, 'y' => $y, 'width' => $largura, 'height' => $altura]);

// Salvar a nova imagem em um arquivo
imagejpeg($novaImagem, 'caminho/para/imagem_recortada.jpg');

// Liberar a memória
imagedestroy($novaImagem);
imagedestroy($imagem);
?>