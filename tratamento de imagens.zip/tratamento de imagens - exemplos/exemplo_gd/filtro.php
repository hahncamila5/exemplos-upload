<?php 
// Carregar a imagem original
$imagem = imagecreatefromjpeg('caminho/para/imagem.jpg');

// Aplicar ajustes
imagefilter($imagem, IMG_FILTER_BRIGHTNESS, 20);  // Ajustar brilho (valor entre -255 e 255)
imagefilter($imagem, IMG_FILTER_CONTRAST, -10);  // Ajustar contraste (valor entre -100 e 100)
imagefilter($imagem, IMG_FILTER_SATURATION, -20); // Ajustar saturação (valor entre -100 e 100)

// Salvar a imagem resultante em um novo arquivo
imagejpeg($imagem, 'caminho/para/nova_imagem.jpg');

// Liberar a memória
imagedestroy($imagem);

?>