<?php
// Definir o tipo de conteúdo como imagem JPEG
header('Content-Type: image/jpeg');

// Ou, no caso de uma imagem PNG
// header('Content-Type: image/png');

// Ou, no caso de uma imagem GIF
// header('Content-Type: image/gif');

// Ler o arquivo de imagem e exibir no navegador
readfile('caminho/para/imagem.jpg');
?>