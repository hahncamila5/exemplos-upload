<?php 
// Carregar a imagem original
$imagem = imagecreatefromjpeg('caminho/para/imagem.jpg');

// Definir as novas dimensões
$novaLargura = 500;
$novaAltura = 300;

// Criar uma nova imagem redimensionada
$novaImagem = imagecreatetruecolor($novaLargura, $novaAltura);

// Redimensionar a imagem original para a nova imagem
imagecopyresampled($novaImagem, $imagem, 0, 0, 0, 0, $novaLargura, $novaAltura, imagesx($imagem), imagesy($imagem));

// Salvar a nova imagem em um arquivo
imagejpeg($novaImagem, 'caminho/para/imagem_redimensionada.jpg');

// Liberar a memória
imagedestroy($novaImagem);
imagedestroy($imagem);
?>