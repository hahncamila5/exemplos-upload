<?php
// Carregar a imagem original
$imagem = new Imagick('caminho/para/imagem.jpg');

// Definir as coordenadas e dimensões do retângulo de corte
$x = 100;
$y = 100;
$largura = 200;
$altura = 150;

// Recortar a imagem original
$imagem->cropImage($largura, $altura, $x, $y);

// Salvar a nova imagem em um arquivo
$imagem->writeImage('caminho/para/imagem_recortada.jpg');

// Liberar a memória
$imagem->destroy();

?>