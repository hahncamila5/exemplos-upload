<?php
// Carregar a imagem original
$imagem = new Imagick('caminho/para/imagem.jpg');

// Definir as novas dimensões
$novaLargura = 500;
$novaAltura = 300;

// Redimensionar a imagem original
$imagem->resizeImage($novaLargura, $novaAltura, Imagick::FILTER_LANCZOS, 1);

// Salvar a nova imagem em um arquivo
$imagem->writeImage('caminho/para/imagem_redimensionada.jpg');

// Liberar a memória
$imagem->destroy();
?>